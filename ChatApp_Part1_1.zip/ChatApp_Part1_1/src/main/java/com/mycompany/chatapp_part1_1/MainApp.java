/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.chatapp_part1_1;

import java.util.Scanner;

/**
 *
 * @author user 1
 */
public class MainApp {

     public static void main(String[] args){
        
        // Scanner allows the user to enter information
        Scanner input = new Scanner(System.in);
     
        // Create an object of the Login class
        Login login = new Login();
     
        // --- REGISTRATION SECTION ---
        System.out.println("=== USER REGISTRATION ===");
     
        System.out.print("Enter a username: ");
        String username = input.nextLine();
     
        System.out.print("Enter a password: ");
        String password = input.nextLine();
     
        System.out.print("Enter your South African phone number (+27...): ");
        String phone = input.nextLine();
    
        // Register user
        String response = login.registerUser(username, password, phone);
     
        // Show the registration message
        System.out.println(response);
     
        // --- LOGIN SECTION ---
        System.out.println("\n=== USER LOGIN ===");
     
        System.out.print("Enter your username: ");
        String loginUsername = input.nextLine();
     
        System.out.print("Enter your password: ");
        String loginPassword = input.nextLine();
     
        // Check login
        boolean loggedIn = login.loginUser(loginUsername, loginPassword);
     
        // Print correct login message
        String loginMessage = login.returnLoginStatus(loggedIn);
        System.out.println(loginMessage);
        
        input.close();
    }
}
